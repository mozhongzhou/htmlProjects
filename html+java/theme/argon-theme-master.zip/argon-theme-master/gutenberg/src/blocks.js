import './alert/alert.js';
import './admonition/admonition.js';
import './collapse/collapse.js';
import './github/github.js';
import './timeline/timeline.js';
import './progressbar/progressbar.js';
import './todolist/todolist.js';
import './tabpanel/tabpanel.js';